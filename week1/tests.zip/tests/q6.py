OK_FORMAT = True

test = {   'name': 'q6',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> assert len(sol) == 6\n', 'hidden': False, 'locked': False}, {'code': '>>> assert sol == [5, 10, 15, 20, 25, 30]\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
