OK_FORMAT = True

test = {   'name': 'q2',
    'points': 5,
    'suites': [   {   'cases': [{'code': '>>> assert calc_diag(3, 4) == 5\n', 'hidden': False, 'locked': False}, {'code': '>>> assert calc_diag(5, 12) == 13\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
