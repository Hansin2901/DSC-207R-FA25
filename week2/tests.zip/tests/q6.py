OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert a_norm.shape == (3, 5)\n',
                                       'failure_message': 'The normalized array should stay 3 by 5. Use keepdims=True when computing row means so the dimensions remain aligned.',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
