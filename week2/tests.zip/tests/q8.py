OK_FORMAT = True

test = {   'name': 'q8',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> assert dot_product_array.shape == (500, 500)\n',
                                       'failure_message': "The result matrix should be 500 by 500. Make sure you're multiplying two square arrays of that size with np.matmul.",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
